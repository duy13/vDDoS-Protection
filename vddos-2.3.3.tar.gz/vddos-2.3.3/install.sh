#!/bin/bash
PATH=/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/bin
source ~/.bashrc  >/dev/null 2>&1
source ~/.bash_profile  >/dev/null 2>&1

vddos_version='2.3.3'


if [ "$1" = "master" ]; then
	yourchoice=1
else
if [ "$1" = "slave" ]; then
	yourchoice=2
else


clear
# Chao mung:
red='\e[0;31m'
yellow='\e[1;33m'
no='\e[0m'
Background1='\e[41m\e[1;33m'
yourchoice=''

tput cup 1 $(($(tput cols)/2-38))
echo -e "${red}################################ ${yellow}WELCOME TO${red} ###############################${no}"
tput cup 2 $(($(tput cols)/2-38))
echo -e "${red}######################### ${yellow}vDDoS Proxy Protection${red} ##########################${no}"
tput cup 3 $(($(tput cols)/2-38))
echo -e "${red}################################ ${yellow}INSTALLER${red} ################################${no}"
echo ""
echo "Please choose a version for vDDoS Server:
$(for i in {16..29} {29..16} ; do echo -en "\e[38;5;${i}m__\e[0m" ; done ; echo)

 1. MASTER
 2. SLAVE
 3. REMOVE ALL

 0. Exit

$(for i in {16..29} {29..16} ; do echo -en "\e[38;5;${i}m__\e[0m" ; done ; echo)"
echo -n "Enter your choice [1, 2, 3 or 0]: " 
read yourchoice

fi
fi


if [ "$yourchoice" != "3" ]; then
if [ -f /vddos/vddos  ]; then
	echo 'ERROR! vDDoS service is already installed! 
Please run command "vddos help" to learn Command Line Usage vddos!'
	exit 0
fi
fi


if [ "$yourchoice" = "1" ]; then
	echo ''
	echo '==>	MASTER SERVER INSTALL...'

	if [ ! -f vddos-$vddos_version.sh  ]; then
		echo 'ERROR! vddos-'$vddos_version'.sh not found!'
		exit 0
	fi
	if [ ! -d vddos  ]; then
		echo 'ERROR! "vddos" not found!'
		exit 0
	fi
	if [ ! -d master  ]; then
		echo 'ERROR! "master" not found!'
		exit 0
	fi
	if [ ! -d auto-add  ]; then
		echo 'ERROR! "auto-add" not found!'
		exit 0
	fi
	if [ ! -d auto-switch  ]; then
		echo 'ERROR! "auto-switch" not found!'
		exit 0
	fi
	# Install for vDDoS Service
	chmod 700 vddos-$vddos_version.sh
	./vddos-$vddos_version.sh setup
	./vddos-$vddos_version.sh autostart
	if [ ! -f /vddos/vddos  ]; then
		echo 'ERROR! vDDoS installation failed!'
		exit 0
	fi
	cp vddos-$vddos_version.sh /usr/bin/vddos
	chmod 700 /usr/bin/vddos
	echo '@monthly root /usr/bin/vddos-master synall && sleep 5 && /usr/bin/vddos-master reloadall' >> /etc/crontab
	echo '2 2 * * * root acme.sh --upgrade ; /usr/bin/vddos-autoadd ssl-again' >> /etc/crontab
	
	#### Install for MASTER Server
	cp -a master /vddos
	chmod 700 /vddos/master/master.sh
	ln -s /vddos/master/master.sh /usr/bin/vddos-master


	cp -a auto-add /vddos
	chmod 700 /vddos/auto-add/*.sh
	ln -s /vddos/auto-add/vddos-add.sh /usr/bin/vddos-add
	ln -s /vddos/auto-add/vddos-autoadd.sh /usr/bin/vddos-autoadd


	cp -a auto-switch /vddos
	chmod 700 /vddos/auto-switch/*.sh
	ln -s /vddos/auto-switch/vddos-autoswitch.sh /usr/bin/vddos-autoswitch
	ln -s /vddos/auto-switch/vddos-switch.sh /usr/bin/vddos-switch
	ln -s /vddos/auto-switch/vddos-sensor.sh /usr/bin/vddos-sensor

	if [ -f /vddos/vddos  ]; then
		curl -L https://github.com/duy13/vDDoS-Layer4-Mapping/raw/master/vddos-layer4-mapping -o /usr/bin/vddos-layer4
		chmod 700 /usr/bin/vddos-layer4
		echo 'Congratulations! Master vDDoS Server installed successfully!'
		exit 0
	fi
fi


if [ "$yourchoice" = "2" ]; then
	echo ''
	echo '==>	SLAVE SERVER INSTALL...'

	if [ ! -f vddos-$vddos_version.sh  ]; then
		echo 'ERROR! vddos-'$vddos_version'.sh not found!'
		exit 0
	fi
	if [ ! -d vddos  ]; then
		echo 'ERROR! "vddos" not found!'
		exit 0
	fi
	if [ ! -d slave  ]; then
		echo 'ERROR! "slave" not found!'
		exit 0
	fi

	# Install for vDDoS Service
	chmod 700 vddos-$vddos_version.sh
	./vddos-$vddos_version.sh setup
	./vddos-$vddos_version.sh autostart
	if [ ! -f /vddos/vddos  ]; then
		echo 'ERROR! vDDoS installation failed!'
		exit 0
	fi
	cp vddos-$vddos_version.sh /usr/bin/vddos
	chmod 700 /usr/bin/vddos

	cp -a auto-switch /vddos
	chmod 700 /vddos/auto-switch/*.sh
	ln -s /vddos/auto-switch/vddos-autoswitch.sh /usr/bin/vddos-autoswitch
	ln -s /vddos/auto-switch/vddos-switch.sh /usr/bin/vddos-switch
	ln -s /vddos/auto-switch/vddos-sensor.sh /usr/bin/vddos-sensor

	#### Install for SLAVE Server

	cp -a slave /vddos
	chmod 700 /vddos/slave/slave.sh
	ln -s /vddos/slave/slave.sh /usr/bin/vddos-slave
	echo '* * * * * root /usr/bin/vddos-slave' >> /etc/crontab

	if [ -f /vddos/vddos  ]; then
		curl -L https://github.com/duy13/vDDoS-Layer4-Mapping/raw/master/vddos-layer4-mapping -o /usr/bin/vddos-layer4
		chmod 700 /usr/bin/vddos-layer4
		echo 'Congratulations! Slave vDDoS Server installed successfully!'
		exit 0
	fi
fi

if [ "$yourchoice" = "3" ]; then
	echo ''
	echo ' REMOVE ALL!!! 
	In 10 seconds countdown ALL vDDoS Service will be removed... 
	Press Ctrl+C to stop this:'
	echo '	Wait 10s...'
	sleep 15
	echo '...'
	sleep 2
	echo '...'
	date=`date +"[DATE=%d-%m-%Y_TIME=%Hh%M]"`
	echo ' START BACKUP ALL to vDDoS-BAK-'$date''
	mkdir -p /root/vDDoS-BAK-$date
	mv /vddos/ /root/vDDoS-BAK-$date  >/dev/null 2>&1
	cp -a /letsencrypt /root/vDDoS-BAK-$date  >/dev/null 2>&1
	echo 'START REMOVE ALL...'
	/usr/bin/vddos stop  >/dev/null 2>&1
	rm -rf /vddos
	rm -rf /usr/lib64/vddos/modules
	rm -rf /var/log/vddos
	rm -rf /var/cache/vddos
	rm -rf /usr/bin/vddos*
	echo 'REMOVE ALL WAS SUCCESSFUL!!!'
	exit 0
fi


if [ "$yourchoice" = "0" ]; then
	exit 0
fi

exit 0