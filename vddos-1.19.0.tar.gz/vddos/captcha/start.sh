#!/bin/sh

/vddos/python/bin/gunicorn -c gunicorn.conf.py app:app
