# Generated from 'AppleHelp.h'

kAHInternalErr = -10790
kAHInternetConfigPrefErr = -10791
kAHTOCTypeUser = 0
kAHTOCTypeDeveloper = 1
