Put news entry ``blurb`` files for the *Tests* section in this directory.
