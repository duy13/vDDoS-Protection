Put news entry ``blurb`` files for the *Windows* section in this directory.
