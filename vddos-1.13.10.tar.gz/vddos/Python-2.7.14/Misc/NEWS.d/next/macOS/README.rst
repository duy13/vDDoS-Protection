Put news entry ``blurb`` files for the *macOS* section in this directory.
