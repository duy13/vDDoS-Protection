Put news entry ``blurb`` files for the *Core and Builtins* section in this directory.
