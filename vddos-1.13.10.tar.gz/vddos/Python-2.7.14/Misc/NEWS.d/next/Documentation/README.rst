Put news entry ``blurb`` files for the *Documentation* section in this directory.
