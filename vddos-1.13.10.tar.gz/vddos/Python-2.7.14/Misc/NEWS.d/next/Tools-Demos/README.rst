Put news entry ``blurb`` files for the *Tools/Demos* section in this directory.
