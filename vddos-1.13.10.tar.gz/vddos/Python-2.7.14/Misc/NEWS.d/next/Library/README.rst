Put news entry ``blurb`` files for the *Library* section in this directory.
