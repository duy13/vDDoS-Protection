Put news entry ``blurb`` files for the *C API* section in this directory.
