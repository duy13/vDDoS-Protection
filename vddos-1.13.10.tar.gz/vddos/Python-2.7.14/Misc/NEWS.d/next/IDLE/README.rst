Put news entry ``blurb`` files for the *IDLE* section in this directory.
