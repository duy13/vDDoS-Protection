Put news entry ``blurb`` files for the *Security* section in this directory.
