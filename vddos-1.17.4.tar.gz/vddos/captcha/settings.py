DEBUG=False
RE_SECRETS = { 'your-domain.com': '6Lcr6QkUAAAAADFwJx58rhO-ulZGWIQLQckgW2Pz',
               'your-domain2.com': 'per_domain_recaptcha_secret_key2' }

